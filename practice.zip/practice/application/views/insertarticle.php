<?php include('header.php') ?>
<?php 
    $articledata = ['name'=>'article_form','class'=>'form'];
?>
<div class="row">
    <div class="col-lg-12">
        <h1>Add Article</h1>
        <hr>
    </div>
</div>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <?php echo form_open('article/addarticle',$articledata); ?>
            <div class="form-group">
                <?=form_label('Article Title','title')?>
                <?=form_error('title','<div class="text-danger">', '</div>')?>
                <?=form_input(['name'=>'title','placeholder'=>'Enter article title','class'=>'form-control','auto-focus'=>'true','value'=>set_value('title')])?>
            </div>
            <div class="form-group">
                <?=form_label('Description','description')?>
                <?=form_textarea(['name'=>'description','rows'=>'4','class'=>'form-control','placeholder'=>'Some words...!!'])?>
            </div>
            <div class="form-group">
                <?=form_submit(['name'=>'submit','value'=>'Submit','class'=>"btn btn-primary"])?>
                <?=form_reset(['name'=>'reset','value'=>'Clear','class'=>"btn btn-danger"])?>
            </div>
        <?php echo form_close(); ?>
    </div>
</div>
<?php include('footer.php') ?>