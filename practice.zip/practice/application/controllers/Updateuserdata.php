<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Updateuserdata extends MY_Controller {
    public function __construct()
    {
        parent::__construct();
        $this->load->model("studentdetails");
    }
    public function index($id)
    {
        $this->load->view('updateprofile');        
    }
    public function displayData($id)
    {
        $data['user'] = $this->crudops->dispData($id);
        $this->load->view('updateprofile',$data);
    }
    public function updateUser($id)
    {
        $userid = $id;
        $username = $this->input->post('username'); 
        $password = $this->input->post('password');
        $firstname = $this->input->post('firstname');
        $lastname = $this->input->post('lastname');

        $this->crudops->updatedata($username,$password,$firstname,$lastname,$userid);
        
        return redirect('home');
    }
    public function validate_details()
    {
        $id = $this->session->userdata('user_id');
        $this->form_validation->set_message('is_unique','Data is already exists');
        if($this->form_validation->run('student_details') == FALSE)
        {
            $data['users'] = $this->crudops->dispdata($id);
            $data['countries'] = $this->getCountry();        
            $this->load->view('student_info',$data);
            //print_r($this->input->post());
        }
        else
        {
            $gender = $this->input->post('gender');
            $hobbies = implode(',',$this->input->post('hobbies[]'));
            $birthdate = $this->input->post('birthdate');
            $country = $this->input->post('country');
            $state = $this->input->post('state');
            $city = $this->input->post('city');
            $this->studentdetails->insertDetails($gender,$birthdate,$hobbies,$country,$state,$city,$id);
            return redirect('updateuserdata/allinfo');
        }
    }
    public function adddetails()
    {   
        $userId = $this->session->userdata('user_id');
        $data['users'] = $this->crudops->dispdata($userId);
        $data['countries'] = $this->getCountry();        
        $this->load->view('student_info',$data);
    }
    public function getCountry()
    {
        $data['country'] = $this->studentdetails->getCountry();        
        return $data;
    }
    public function getState($Cid = '')
    {
        $Cid = $this->input->post('countryid');
        $data['states'] = $this->studentdetails->getState($Cid);
        return $data;
    }
    public function getCity($Sid = '')
    {
        $Sid = $this->input->post('stateid');
        $data['city'] = $this->studentdetails->getCity($Sid);
        return $data;
    }
    public function allinfo()
    {
        $data['id'] = $this->session->userdata('user_id');
        $data['name'] = $this->session->userdata('user_name');
        $data['user'] = $this->studentdetails->getUserdata($data['id']);
        $data['city'] = $this->studentdetails->getCitybyId($data['id']);
        $data['state'] = $this->studentdetails->getStatebyId($data['id']);
        $data['country'] = $this->studentdetails->getCountrybyId($data['id']);
        $this->load->view('allinfo',$data);
    }
    public function gender_check()
    {
        if(!$this->input->post('gender'))
        {
            $this->form_validation->set_message('gender_check',"Please select one!");
            return false;
        }
        else
        {
            return true;
        }
    }
    public function state_check()
    {
        if($this->input->post('state') == 0)
        {
            $this->form_validation->set_message('state_check','Please select appropriate state');
            return false;
        }
        else{
            return true;
        }
    }
    public function city_check()
    {
        if($this->input->post('city') == 0)
        {
            $this->form_validation->set_message('city_check','Please select appropriate city');
            return false;
        }
        else{
            return true;
        }
    }
}