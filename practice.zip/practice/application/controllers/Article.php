<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Article extends MY_Controller
{
    public function index()
    {
        $this->load->view('insertarticle');
    }
    public function addarticle()
    {
        if($this->form_validation->run('article_form') == false)
        {
            $this->load->view('insertarticle');
        }
        else
        {
            $this->load->model('articles');

            $title = $this->input->post('title');
            $description = $this->input->post('description');
            $id = $this->session->userdata('user_id');

            if($this->articles->insertdata((int)$id,$title,$description))
            {
                return redirect('article/articlelist');
            }
            else
            {
                return redirect('login');
            }
        }
    }
    public function articlelist()
    {
        $data['articles'] = $this->articles->retfromDb();
        $this->load->view('articlelist',$data);
    }
    public function editArticle($id)
    {
        if($this->form_validation->run('article_form'))
        {
            $articleid = $id;
            $title = $this->input->post('title');
            $description = $this->input->post('description');
            $this->articles->updatearticle($articleid,$title,$description);
            return redirect('article/articlelist');
        }
        else
        {
            return redirect('article/editarticle/'.$id);
        }        
    }
    public function deleteArticle($id)
    {
        $articleid = $id;
        $this->articles->deletearticle($articleid);
        return redirect('article/articlelist');
    }
    public function articlebyid($id)
    {
        $articleid = $id; 
        $data['article'] = $this->articles->getarticlebyid($articleid);
        $this->load->view('editarticle',$data);
    }
}