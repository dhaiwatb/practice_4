<?php

class Articles extends CI_Model{
    public function retFromDb()
    {
        $student_id = $this->session->userdata('user_id');
        $q = $this->db
        ->where('user_id',$student_id)
        ->get('articles');

        //select * from articles where user_id=student_info.id

        if($q->num_rows())  
        {
            return $q->result_array();
        }
        else
        {
            return false;
        }
    }
    public function insertData($student_id,$title,$desc)
    {
        if($this->session->has_userdata('user_id') && $this->session->userdata('user_id') == $student_id)
        {
            $data = ['title'=>$title,'description'=>$desc,'user_id'=>$student_id];
            $q = $this->db->set($data)
            ->insert('articles');
            return true;
        }
        else
        {
            return false;
        }
    }
    public function deletearticle($id)
    {
        $q = $this->db
        ->where('id',$id)
        ->delete('articles');
    }
    public function updatearticle($articleid,$title,$desc)
    {
        $data = ['title'=>$title,'description'=>$desc];
        $q = $this->db
        ->set($data)
        ->where('id',$articleid)
        ->where('user_id',$this->session->userdata('user_id'))
        ->update('articles');
    }
    public function getArticlebyid($id)
    {
        $q = $this->db->where('id',$id)
        ->get('articles');
        
        if($q->num_rows() > 0)
        {
            return $q->result_array();
        }
        else
        {
            echo 'no data selected';
            return false;
        }
    }
}