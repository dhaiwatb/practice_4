<?php include 'header.php' ?>

<div class="row">
    <div class="col-lg-8">
        <?php   if(is_array($user) && count($user) >0): ?>  
            <h1>All details are added</h1>
            <hr>
            <?php foreach($user as $row): ?>
                <p><?php echo $row->id; ?></p>
                <p><?php echo $row->gender;?></p>
                <p><?php echo $row->hobbies; ?></p>
                <p><?php echo $row->birthdate; ?></p>
            <?php endforeach; ?>
            <p><?php echo($city->name); ?></p>
            <p><?php echo($state->name); ?></p>
            <p><?php echo($country->country_name); ?></p>
        <?php else: ?>
            <h1>No data available!</h1>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php' ?>