
</div>


<script type="text/javascript">
    $(document).ready(function () {
        //$( "#datepicker" ).datepicker();
        $(function(){
            $("#datepicker").datepicker({
                  dateFormat: "yy-mm-dd"
            });
        });

        //$("#state-drop-down").hide();
        //$("#city-drop-down").hide();
        $("#country").change(function(){
            var countryId = $("#country").val();
            if(countryId > 0)
            {
                $("#state-drop-down").show();
                $.ajax({
                    type:'post',
                    url: '<?=base_url()."Updateuserdata/getState"?>',
                    data:'countryid='+countryId,
                    success:function(result){
                        $('#state-drop-down').find('#state').html(result);
                    }                    
                });
            }
            else
            {
                alert('Select proper value');
                $("#state-drop-down").hide();
                $("#city-drop-down").hide();
                return false;
            }
        });
        $("#state").change(function(){
            var stateId = $("#state").val();
            if(stateId > 0 && stateId != 0)
            {
                $("#city-drop-down").show();
                $.ajax({
                    type:'post',
                    url: '<?=base_url()."Updateuserdata/getCity"?>',
                    data:'stateid='+stateId,
                    success:function(result){
                        $('#city-drop-down').find('#city').html(result);
                    }                    
                });
            }
            else
            {
                alert('Select proper value');
                $("#city-drop-down").hide();
                return false;
            }
        });
        $("#city").change(function(){
            var cityId = $("#city").val();
            if(cityId < 0 && cityId != 0)
            {
                alert('Select proper value');
                return false;
            }
            else
            {
                //alert(cityId);
            }
        });
        //$("#student-table").find("tr")
    });
</script>
<script type='text/javascript' src="<?=base_url().'asset/js/cust.js'?>"></script>
</body>
</html>
