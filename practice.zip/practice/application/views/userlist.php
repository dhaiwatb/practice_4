<?php include('header.php'); ?>	
<div class="row">
    <div class="col-lg-12">
        <h1>All Users</h1>
        <hr>
    </div>
</div>
<div class="row">
    <div class="col-lg-8 mx-auto">
        <table class="table" id="student-list">
            <thead>
                <tr>
                    <th width="12%">User Id</th>
                    <th width="20%">Username</th>
                    <th width="20%">Firstname</th>
                    <th width="20%">Lastname</th>
                    <?php if($this->session->has_userdata('user_id')):?>
                        <th class="text-center" width="28%">Action</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php   if(is_array($users) && count($users) >0): ?>                    
                <?php foreach($users as $user): ?>
                    <tr>
                        <td width="12%"><?=$user['id'] ?></td>    
                        <td width="20%"><?=ucfirst($user['uname']) ?></td>
                        <td width="20%"><?=ucfirst($user['fname']) ?></td>
                        <td width="20%"><?=ucfirst($user['lname']) ?></td>
                        <?php if($this->session->has_userdata('user_id')):?>
                            <td class="mx-auto" style="padding:0px 0px;" width="27%"> 
                                <nav class="nav nav-pills">
                                    <a class="nav-link" href  ="<?=base_url().'updateuserdata/displaydata/'.$user['id']?>">
                                        <button class="btn btn-primary">Edit</button>
                                    </a>
                                    <a class="nav-link" href="<?=base_url().'home/deletedata/'.$user['id']?>">
                                        <button class="btn btn-danger">Delete</button>
                                    </a>
                                </nav>                                
                            </td>
                            <td width="1%">
                                <a id="collapseButton-<?=$user['id']?>" href="#" role="button" data-target="#collapseExample-<?=$user['id']?>">
                                    <i class="fa fa-info"></i>
                                </a>
                            </td>
                            <td style="display: none;">
                                <div id="collapseDiv-<?=$user['id']?>">
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Impedit aut in, amet voluptatem omnis est consequuntur, magnam commodi adipisci voluptates deserunt ut earum inventore deleniti dolore fuga quibusdam. Fugit, laborum.
                                </div>
                            </td>
                        <?php endif; ?>                        
                    </tr>
                <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td>
                            <span>
                                <p class="text-primary">
                                    No records found.
                                </p>
                            </span>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>    
        </table>
        
          <?=$this->pagination->create_links();?>
        
    </div>
</div>
<?php include('footer.php'); ?>